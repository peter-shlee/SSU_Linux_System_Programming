ddd ddd ddd dd
